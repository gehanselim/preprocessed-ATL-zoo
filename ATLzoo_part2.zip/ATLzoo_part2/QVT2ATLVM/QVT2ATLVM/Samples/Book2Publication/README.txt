This QVT sample comes from the SmartQVT (http://smartqvt.elibel.tm.fr/) samples.
You need a QVT front-end (e.g., SmartQVT) to parse the .qvt file into the .ecore file.
