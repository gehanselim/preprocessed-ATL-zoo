package de.tudresden.atl.drivers.tudemf4atl;

import java.io.InputStream;

import org.eclipse.emf.common.util.URI;
import org.eclipse.m2m.atl.drivers.emf4atl.ASMEMFModel;
import org.eclipse.m2m.atl.engine.AtlEMFModelHandler;
import org.eclipse.m2m.atl.engine.vm.ModelLoader;
import org.eclipse.m2m.atl.engine.vm.nativelib.ASMModel;

/**
 * @author Jendrik Johannes
 *
 */
public class AtlTUDEMFModelHandler extends AtlEMFModelHandler {

	public AtlTUDEMFModelHandler() {
		super();
	}
    
	public ASMModel loadModel(String name, ASMModel metamodel, InputStream in) {
		ASMModel ret = null;
		
		try {
			ret = ASMTUDEMFModel.loadASMTUDEMFModel(name, (ASMEMFModel)metamodel, in, ml);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	public ASMModel loadModel(String name, ASMModel metamodel, URI uri) {
		ASMModel ret = null;
		
		try {
			ret = ASMTUDEMFModel.loadASMTUDEMFModel(name, (ASMEMFModel)metamodel, uri, ml);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}

	public ASMModel loadModel(String name, ASMModel metamodel, String uri) {
		ASMModel ret = null;
		
		try {
			ret = ASMTUDEMFModel.loadASMTUDEMFModel(name, (ASMEMFModel)metamodel, uri, ml);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return ret;
	}
	
    /**
     * @see ASMTUDEMFModel#newASMTUDEMFModel(String, String, ASMEMFModel, ModelLoader)
     */
    public ASMModel newModel(String name, String uri, ASMModel metamodel) {
        ASMModel ret = null;
        
        if(uri == null)
        	uri = name;
        
        try {
            ret = ASMTUDEMFModel.newASMTUDEMFModel(name, uri, (ASMEMFModel)metamodel, ml);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return ret;
    }

	public boolean isHandling(ASMModel model) {
		return model instanceof ASMTUDEMFModel;
	}

}
